Proyecto de laboratorio - Sistema de Ferretería
Abrir la carpeta FerreteriaPatrones en IntelliJ IDEA.
Main: pe.edu.ferreteria.app.FerreteriaApp
