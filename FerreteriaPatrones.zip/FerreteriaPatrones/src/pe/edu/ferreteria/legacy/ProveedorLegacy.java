package pe.edu.ferreteria.legacy;

public class ProveedorLegacy {
public int existencias(int idExterno) {
return idExterno==100?40:idExterno==200?15:0;
}
}
