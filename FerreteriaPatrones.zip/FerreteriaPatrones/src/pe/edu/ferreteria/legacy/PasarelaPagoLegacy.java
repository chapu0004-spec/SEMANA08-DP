package pe.edu.ferreteria.legacy;

public class PasarelaPagoLegacy {
public boolean cobrar(double monto, String moneda) {
        System.out.println("Pago legacy: "+monto+" "+moneda);
return monto>0;
}
}
