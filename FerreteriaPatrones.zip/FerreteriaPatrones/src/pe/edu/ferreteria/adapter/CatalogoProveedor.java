package pe.edu.ferreteria.adapter;

public interface CatalogoProveedor {
int consultarStock(String codigo);
}
