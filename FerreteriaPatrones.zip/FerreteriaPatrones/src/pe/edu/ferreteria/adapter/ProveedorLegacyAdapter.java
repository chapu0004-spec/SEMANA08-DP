package pe.edu.ferreteria.adapter;

import pe.edu.ferreteria.legacy.ProveedorLegacy;

public class ProveedorLegacyAdapter implements CatalogoProveedor {
private final ProveedorLegacy proveedor;
public ProveedorLegacyAdapter(ProveedorLegacy p) {
proveedor=p;
}
public int consultarStock(String codigo) {
        int id=Integer.parseInt(codigo.replace("P-", ""));
return proveedor.existencias(id);
}
}
