package pe.edu.ferreteria.adapter;

public interface ProcesadorPago {
boolean procesar(double monto, String medio);
}
