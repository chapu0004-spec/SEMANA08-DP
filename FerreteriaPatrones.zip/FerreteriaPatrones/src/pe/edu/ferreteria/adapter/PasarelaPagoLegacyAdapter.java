package pe.edu.ferreteria.adapter;

import pe.edu.ferreteria.legacy.PasarelaPagoLegacy;

public class PasarelaPagoLegacyAdapter implements ProcesadorPago {
private final PasarelaPagoLegacy adaptee;
public PasarelaPagoLegacyAdapter(PasarelaPagoLegacy a) {
adaptee=a;
}
public boolean procesar(double monto, String medio) {
        return adaptee.cobrar(monto, "PEN");
}
}
