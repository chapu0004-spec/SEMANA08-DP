package pe.edu.ferreteria.app;

import pe.edu.ferreteria.model.*;
import pe.edu.ferreteria.service.*;
import pe.edu.ferreteria.adapter.*;
import pe.edu.ferreteria.legacy.*;
import pe.edu.ferreteria.facade.*;
import java.util.*;

public class FerreteriaApp {
public static void main(String[] args) {
Inventario inv=new Inventario();
        Producto martillo=new Producto("P-100", "Martillo", 35.90);
        Producto taladro=new Producto("P-200", "Taladro", 249.90);
inv.registrarProducto(martillo, 10);
inv.registrarProducto(taladro, 5);
        Cliente cliente=new Cliente("45879632", "Ana Torres");
ProcesadorPago proc=new PasarelaPagoLegacyAdapter(new PasarelaPagoLegacy());
VentaFacade vf=new VentaFacade(inv, proc);
        Venta venta=vf.procesarVenta(cliente, List.of(new DetalleVenta(martillo, 2, martillo.getPrecio())), "TARJETA", true);
        System.out.println("Cliente: "+venta.getCliente());
        System.out.println("Total: S/ "+String.format("%.2f", venta.calcularTotal()));
        System.out.println("Stock martillo: "+inv.consultarStock("P-100"));
        Proveedor prov=new Proveedor("PR-01", "20123456789", "Proveedor Central", true);
ComprasFacade cf=new ComprasFacade(inv, new ProveedorLegacyAdapter(new ProveedorLegacy()));
cf.reponerProducto(prov, martillo, 5);
        System.out.println("Stock luego de reposición: "+inv.consultarStock("P-100"));
}
}
