package pe.edu.ferreteria.facade;

import pe.edu.ferreteria.model.Producto;
import pe.edu.ferreteria.service.Inventario;

public class InventarioFacade {
private final Inventario inventario;
public InventarioFacade(Inventario i) {
inventario=i;
}
public void registrarProducto(Producto p, int c) {
inventario.registrarProducto(p, c);
}
public boolean consultarDisponibilidad(String c, int q) {
return inventario.hayStock(c, q);
}
public void ingresarStock(String c, int q) {
inventario.ingresar(c, q);
}
public void retirarStock(String c, int q) {
inventario.retirar(c, q);
}
public Inventario getInventario() {
return inventario;
}
}
