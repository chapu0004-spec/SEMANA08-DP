package pe.edu.ferreteria.facade;

import pe.edu.ferreteria.adapter.ProcesadorPago;
import pe.edu.ferreteria.model.*;
import pe.edu.ferreteria.service.Inventario;
import java.util.*;

public class VentaFacade {
private final Inventario inventario;
private final ProcesadorPago pago;
private int sec=1;
public VentaFacade(Inventario i, ProcesadorPago p) {
inventario=i;
pago=p;
}
public Venta procesarVenta(Cliente cliente, List<DetalleVenta> items, String medioPago, boolean requiereEntrega) {
        for(DetalleVenta d:items)if(!inventario.hayStock(d.getProducto().getCodigo(), d.getCantidad()))throw new IllegalStateException("Stock insuficiente");
Venta v=new Venta(sec++, cliente);
items.forEach(v::agregarDetalle);
double total=v.calcularTotal();
        if(!pago.procesar(total, medioPago))throw new IllegalStateException("Pago rechazado");
for(DetalleVenta d:items)inventario.retirar(d.getProducto().getCodigo(), d.getCantidad());
        Pago pg=new Pago(v.getId(), total, medioPago, "APROBADO");
        Comprobante c=new Comprobante("B"+v.getId(), "BOLETA", total);
if(requiereEntrega) {
            ServicioEntrega e=new ServicioEntrega(v.getId(), "Dirección del cliente", 10);
            System.out.println("Entrega: "+e.getEstado());
}
        System.out.println("Comprobante "+c.getNumero()+" - "+pg.getEstado());
return v;
}
}
