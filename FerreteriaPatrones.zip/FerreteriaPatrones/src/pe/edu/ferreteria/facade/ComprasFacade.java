package pe.edu.ferreteria.facade;

import pe.edu.ferreteria.adapter.CatalogoProveedor;
import pe.edu.ferreteria.model.*;
import pe.edu.ferreteria.service.Inventario;

public class ComprasFacade {
private final Inventario inventario;
private final CatalogoProveedor catalogo;
private int sec=1;
public ComprasFacade(Inventario i, CatalogoProveedor c) {
inventario=i;
catalogo=c;
}
public PedidoCompra reponerProducto(Proveedor proveedor, Producto producto, int cantidad) {
        if(!proveedor.isActivo())throw new IllegalStateException("Proveedor inactivo");
        if(catalogo.consultarStock(producto.getCodigo())<cantidad)throw new IllegalStateException("Proveedor sin stock suficiente");
        PedidoCompra p=new PedidoCompra(sec++, proveedor, "CREADO");
p.agregarDetalle(new DetallePedidoCompra(producto, cantidad, producto.getPrecio()*0.7));
inventario.ingresar(producto.getCodigo(), cantidad);
        p.setEstado("RECIBIDO");
return p;
}
}
