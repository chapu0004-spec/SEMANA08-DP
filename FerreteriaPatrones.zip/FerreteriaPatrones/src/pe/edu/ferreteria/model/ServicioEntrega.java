package pe.edu.ferreteria.model;

public class ServicioEntrega {
private final int id;
private final String direccion;
private final double costo;
private String estado;
public ServicioEntrega(int id, String d, double c) {
this.id=id;
direccion=d;
costo=c;
        estado="PROGRAMADA";
}
public void marcarDespachada() {
        estado="DESPACHADA";
}
public void marcarEntregada() {
        estado="ENTREGADA";
}
public String getEstado() {
return estado;
}
public String getDireccion() {
return direccion;
}
public double getCosto() {
return costo;
}
}
