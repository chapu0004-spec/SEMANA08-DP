package pe.edu.ferreteria.model;

public class Pago {
private final int id;
private final double monto;
private final String medio;
private String estado;
public Pago(int id, double monto, String medio, String estado) {
this.id=id;
this.monto=monto;
this.medio=medio;
this.estado=estado;
}
public int getId() {
return id;
}
public double getMonto() {
return monto;
}
public String getMedio() {
return medio;
}
public String getEstado() {
return estado;
}
public void setEstado(String e) {
estado=e;
}
}
