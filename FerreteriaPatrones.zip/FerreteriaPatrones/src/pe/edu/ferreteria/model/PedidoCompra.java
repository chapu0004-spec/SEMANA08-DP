package pe.edu.ferreteria.model;

import java.util.*;

public class PedidoCompra {
private final int id;
private final Proveedor proveedor;
private String estado;
private final List<DetallePedidoCompra> detalles=new ArrayList<>();
private Empleado empleado;
public PedidoCompra(int id, Proveedor p, String estado) {
this.id=id;
proveedor=p;
this.estado=estado;
}
public void agregarDetalle(DetallePedidoCompra d) {
detalles.add(d);
}
public double calcularTotal() {
return detalles.stream().mapToDouble(DetallePedidoCompra::subtotal).sum();
}
public int getId() {
return id;
}
public Proveedor getProveedor() {
return proveedor;
}
public String getEstado() {
return estado;
}
public void setEstado(String e) {
estado=e;
}
public List<DetallePedidoCompra> getDetalles() {
return Collections.unmodifiableList(detalles);
}
public void setEmpleado(Empleado e) {
empleado=e;
}
public Empleado getEmpleado() {
return empleado;
}
}
