package pe.edu.ferreteria.model;

public class DetallePedidoCompra {
private final Producto producto;
private final int cantidad;
private final double costoUnitario;
public DetallePedidoCompra(Producto p, int c, double costo) {
producto=p;
cantidad=c;
costoUnitario=costo;
}
public Producto getProducto() {
return producto;
}
public int getCantidad() {
return cantidad;
}
public double getCostoUnitario() {
return costoUnitario;
}
public double subtotal() {
return cantidad*costoUnitario;
}
}
