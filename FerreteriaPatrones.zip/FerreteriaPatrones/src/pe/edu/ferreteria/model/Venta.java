package pe.edu.ferreteria.model;

import java.util.*;

public class Venta {
private final int id;
private final Cliente cliente;
private final List<Producto> productos=new ArrayList<>();
private final List<DetalleVenta> detalles=new ArrayList<>();
private Empleado empleado;
public Venta(int id, Cliente c) {
this.id=id;
cliente=c;
}
public void agregarProducto(Producto p) {
        if(p==null)throw new IllegalArgumentException("Producto requerido");
productos.add(p);
detalles.add(new DetalleVenta(p, 1, p.getPrecio()));
}
public void agregarDetalle(DetalleVenta d) {
detalles.add(d);
for(int i=0;i<d.getCantidad();i++)productos.add(d.getProducto());
}
public double calcularTotal() {
return detalles.isEmpty()?productos.stream().mapToDouble(Producto::getPrecio).sum():detalles.stream().mapToDouble(DetalleVenta::subtotal).sum();
}
public int getId() {
return id;
}
public Cliente getCliente() {
return cliente;
}
public List<Producto> getProductos() {
return Collections.unmodifiableList(productos);
}
public List<DetalleVenta> getDetalles() {
return Collections.unmodifiableList(detalles);
}
public void setEmpleado(Empleado e) {
empleado=e;
}
public Empleado getEmpleado() {
return empleado;
}
}
