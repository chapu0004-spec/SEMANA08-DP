package pe.edu.ferreteria.model;

import java.time.LocalDate;

public class Comprobante {
private final String numero, tipo;
private final LocalDate fecha;
private final double total;
public Comprobante(String n, String t, double total) {
numero=n;
tipo=t;
fecha=LocalDate.now();
this.total=total;
}
public String getNumero() {
return numero;
}
public String getTipo() {
return tipo;
}
public LocalDate getFecha() {
return fecha;
}
public double getTotal() {
return total;
}
}
