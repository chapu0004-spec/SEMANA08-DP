package pe.edu.ferreteria.model;

public class DetalleVenta {
private final Producto producto;
private final int cantidad;
private final double precioUnitario;
public DetalleVenta(Producto p, int c, double pu) {
        if(c<=0)throw new IllegalArgumentException("Cantidad inválida");
producto=p;
cantidad=c;
precioUnitario=pu;
}
public Producto getProducto() {
return producto;
}
public int getCantidad() {
return cantidad;
}
public double getPrecioUnitario() {
return precioUnitario;
}
public double subtotal() {
return cantidad*precioUnitario;
}
}
