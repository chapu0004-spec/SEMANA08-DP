package pe.edu.ferreteria.service;

import pe.edu.ferreteria.model.Producto;
import java.util.*;

public class Inventario {
private final Map<String, Producto> productos=new HashMap<>();
private final Map<String, Integer> stock=new HashMap<>();
public void registrarProducto(Producto p, int c) {
        if(c<0)throw new IllegalArgumentException("Stock inválido");
productos.put(p.getCodigo(), p);
stock.put(p.getCodigo(), c);
}
public Producto buscar(String c) {
return productos.get(c);
}
public int consultarStock(String c) {
return stock.getOrDefault(c, 0);
}
public boolean hayStock(String c, int q) {
return q>0&&consultarStock(c)>=q;
}
public void retirar(String c, int q) {
        if(!hayStock(c, q))throw new IllegalStateException("Stock insuficiente");
stock.put(c, consultarStock(c)-q);
}
public void ingresar(String c, int q) {
        if(!productos.containsKey(c))throw new IllegalArgumentException("Producto no registrado");
        if(q<=0)throw new IllegalArgumentException("Cantidad inválida");
stock.put(c, consultarStock(c)+q);
}
}
