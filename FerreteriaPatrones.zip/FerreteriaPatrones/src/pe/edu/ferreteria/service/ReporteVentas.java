package pe.edu.ferreteria.service;

import pe.edu.ferreteria.model.Venta;
import java.util.*;

public class ReporteVentas {
private final Collection<Venta> ventas;
public ReporteVentas(Collection<Venta> v) {
ventas=v;
}
public double totalVendido() {
return ventas.stream().mapToDouble(Venta::calcularTotal).sum();
}
public int numeroVentas() {
return ventas.size();
}
public double ticketPromedio() {
return ventas.isEmpty()?0:totalVendido()/numeroVentas();
}
}
